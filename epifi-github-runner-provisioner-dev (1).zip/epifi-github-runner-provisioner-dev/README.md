# epifi-github-runner-provisioner

## Pre-requisites
The installation has been tested to run successfully from an Ubuntu 20.04 LTS.
Install Below utilities
1. Packer 1.7.0 : https://www.packer.io/docs/install
2. Ansible 2.10.2 : https://docs.ansible.com/ansible/latest/installation_guide/intro_installation.html#installing-ansible-on-ubuntu
3. Terraform 0.14.8 : https://learn.hashicorp.com/tutorials/terraform/install-cli#install-terraform 
4. Azure cli 2.20.0 : https://docs.microsoft.com/en-us/cli/azure/install-azure-cli-linux?pivots=apt



## Overview
This repository is used to provision Github Runners on Azure VMs with correct labels.

Workflow includes
1. Build a VM image in provided azure subscription, resource group and region
2. Setup a VNet for runner VMs
3. Deploy runner groups with correct labels

## How to run
### 1. Sign in to Azure with the Azure CLI
```
az login
```
Reference:: https://docs.microsoft.com/en-us/cli/azure/install-azure-cli-linux?pivots=apt

### 2. Build Disk Image Using Packer
2.1 Create Variables.json File with below structure.
```
{
    "client_id": "",
    "client_secret": "",
    "tenant_id": "",
    "subscription_id": "",
    "managed_image_resource_group_name":"RunnerResourceGroup",
    "managed_image_name":"RunnerImage",
    "location":"eastus"
}
```
2.1.1 Get values from below commands
```
# You can get a list of available subscriptions
az account list
# set a default subscription
az account set -s NAME_OR_ID
```

Create service principle
```
az ad sp create-for-rbac --query "{ client_id: appId, client_secret: password, tenant_id: tenant }"
```
Get Subscription ID
```
az account show --query "{ subscription_id: id }"
```

2.1.2 Create a Resource Group
```
az group create --location eastus --name RunnerResourceGroup
```

2.2 Create Disk Image
```
packer build -var-file packer/variables.json packer/packer.json
```
Note the ManagedImageId from output of packer build.

Packer Sample output
```
OSType: Linux
ManagedImageResourceGroupName: RunnerResourceGroup
ManagedImageName: RunnerImage
ManagedImageId: /subscriptions/bf32e340-5493-4f67-bf07-a976e2fe49ff/resourceGroups/RunnerResourceGroup/providers/Microsoft.Compute/images/RunnerImage
ManagedImageLocation: eastus
```
### Create the tfvars file

Configure the state storage backend for terraform
1. For local state management , skip step 2
2. For state management in azure storage account
3. Create a Vnet and Subnets 

2.1 Create a storage account and container
```
az storage account create -n epifitfisa -g RunnerResourceGroup -l eastus --sku Standard_LRS
az storage container create -n tfstate --account-name epifitfisa
```
Note: Storage account name has to be unique at azure Global level

2.2 uncomment the terraform/backend.tf file and provide correct values

3.1 Create a Vnet
```
az network vnet create \
  --name epifivnet \
  --resource-group RunnerResourceGroup \
  --address-prefix 10.0.0.0/16
```
3.2 Create subnet
```
az network vnet subnet create \
--address-prefix 10.0.1.0/24 \
--name epifiSubnet1 \
--vnet-name epifivnet \
--resource-group RunnerResourceGroup
```
```
az network vnet subnet create \
--address-prefix 10.0.2.0/24 \
--name epifiSubnet2 \
--vnet-name epifivnet \
--resource-group RunnerResourceGroup
```

4. Provide Github Personal Access Token (github_pat), User (github_user), Repo(github_repo) and organization in terraform/terraform.tfvars

5. As in file terraform/terraform.tfvars, their is block name `runner_vm_count`, it is for creating multiple runner groups, for example as their is mentioned 2 blocks with name `runner_vm_1` and `runner_vm_2` which concludes 2 runners with different labels, group name and subnets. Here you can as much runners you want to deploy.

6. Provision Runner infrastructure using Terraform
```
cd terraform/
terraform init
terraform plan -out plan.out
terraform apply "plan.out"
```

NOTE: Remove the .terraform directory for a clean install

### Cleanup
```
terraform destroy
```