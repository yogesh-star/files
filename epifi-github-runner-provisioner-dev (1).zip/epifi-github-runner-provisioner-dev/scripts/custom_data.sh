#!/bin/bash

export PAT=${github_pat}
export RUNNER_LABELS_CSV=${runner_labels}

# # Organization level runner registration
# export GITHUB_ORG=squareops
# export token=$(curl -s -XPOST \
#             -H "authorization: token $PAT" \
#             https://api.github.com/orgs/$GITHUB_ORG/actions/runners/registration-token |\
#             jq -r .token)
# cd /opt/actions-runner && su ubuntu -c './config.sh --url https://github.com/$GITHUB_ORG --token $token --name "runner-$(hostname)" --labels $RUNNER_LABELS_CSV --work _work'

# repo level runner registration
export GITHUB_USER=${github_user}
export GITHUB_REPO=${github_repo}
export token=$(curl -s -XPOST \
            -H "authorization: token $PAT" \
            https://api.github.com/repos/$GITHUB_USER/$GITHUB_REPO/actions/runners/registration-token |\
            jq -r .token)
cd /opt/actions-runner && su ubuntu -c './config.sh --url https://github.com/$GITHUB_USER/$GITHUB_REPO --token $token --name "runner-$(hostname)" --labels $RUNNER_LABELS_CSV --work _work'

cd /opt/actions-runner \
    && ./svc.sh install \
    && ./svc.sh start