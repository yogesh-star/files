# ACR_NAME=bigidapps
# SERVICE_PRINCIPAL_NAME=bigid-acr-service-principal

# ACR_REGISTRY_ID=$(az acr show --name $ACR_NAME --query id --output tsv)

# SP_PASSWD=$(az ad sp create-for-rbac --name http://$SERVICE_PRINCIPAL_NAME --scopes $ACR_REGISTRY_ID --role acrpull --query password --output tsv)
# SP_APP_ID=$(az ad sp show --id http://$SERVICE_PRINCIPAL_NAME --query appId --output tsv)

# # Output the service principal's credentials; use these in your services and
# # applications to authenticate to the container registry.
# echo "Service principal ID: $SP_APP_ID"
# echo "Service principal password: $SP_PASSWD"

# https://docs.microsoft.com/en-us/azure/container-registry/container-registry-authentication#service-principal

# Rancher Setup
helm repo add rancher-latest https://releases.rancher.com/server-charts/latest
helm repo update
helm upgrade --install rancher rancher-latest/rancher \
  --namespace cattle-system \
  --set hostname="${RANCHER_DNS}" \
  --set ingress.tls.source="tls-rancher-ingress"

echo "All Done..!"
