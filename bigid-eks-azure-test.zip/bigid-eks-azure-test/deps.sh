#!/usr/bin/env bash

# in super STRICT mode by default
export STRICT=${STRICT:-yes}
test "${STRICT}" != "no" && {
	set -mEeuo pipefail
	shopt -s failglob
	shopt -s globstar
	shopt -s nocaseglob
	shopt -s nullglob
}

export DEBIAN_FRONTEND=noninteractive

errMsg() {
	echo " 'error' : ${0}\n > 'command' : ${1} | 'line number' : ${2} | 'exit status' : ${3}"
}

trap 'errMsg "${BASH_COMMAND}" "${LINENO}" "$?"' ERR

apt-get -yqq update
apt-get -yqq install \
	apt-utils \
	software-properties-common

apt-get -yqq install \
	bash-completion \
	build-essential \
	htop \
	less \
	vim \
	jq \
	apt-transport-https \
	curl \
	git \
	python3 \
	python3-pip \
	unzip

curl -sSL https://aka.ms/InstallAzureCLIDeb |
	bash

cd /tmp

curl -sSL -O \
		https://releases.hashicorp.com/terraform/0.15.0/terraform_0.15.0_linux_amd64.zip &&
	unzip terraform_0.15.0_linux_amd64.zip &&
	mv terraform /bin &&
	cd - &&
	rm terraform_0.15.0_linux_amd64.zip

curl -sSL -O \
	https://dl.k8s.io/release/v1.21.0/bin/linux/amd64/kubectl &&
	chmod +x kubectl &&
	mv kubectl /bin

curl -sSL https://baltocdn.com/helm/signing.asc |
	apt-key add -
echo "deb https://baltocdn.com/helm/stable/debian/ all main" |
	tee /etc/apt/sources.list.d/helm-stable-debian.list

apt-get -yqq update
apt-get -yqq install helm
