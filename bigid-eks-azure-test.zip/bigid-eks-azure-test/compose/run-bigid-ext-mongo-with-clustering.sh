#!/usr/bin/env bash
./run-bigid-ext-mongo.sh
