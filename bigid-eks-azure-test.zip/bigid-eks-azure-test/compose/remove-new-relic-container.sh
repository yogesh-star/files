#!/usr/bin/env bash
docker rm -f newrelic-infra