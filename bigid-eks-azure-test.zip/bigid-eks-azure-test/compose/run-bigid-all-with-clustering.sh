#!/usr/bin/env bash
./run-bigid-all.sh
