## before the installation: ##
Be sure that you connected and able to manage kubernetes cluster with at least 1.16 k8s version, where bigid installed and running.
At this stage of development cluster nodes should have internet access, as well as your laptop's minikube or docker-desktop.

### For installation run: ###

```
NAMESPACE=<BIGIDNAMESPACE> sh install.sh
```

### For destroy run: ###

```
NAMESPACE=<BIGIDNAMESPACE> sh destroy.sh
```

### usefull commands: ###
To see applauncher and its logs, also to delete old launchers:
```
kubectl port-forward --namespace <BIGIDNAMESPACE> svc/argo-server 2746:2746
```
And open ```localhost:2746``` in your browser

To see pods:
```
kubectl get pods -n <BIGIDNAMESPACE>
```
See pod names, then
```
kubectl logs -n <BIGIDNAMESPACE> <PODNAME>
```
For multi-container pods previous command will ask to run it again with container name as last argument:
```
kubectl logs -n <BIGIDNAMESPACE> <PODNAME> <CONTAINERNAME>
```

### For destroy run: ###

```
NAMESPACE=<BIGIDNAMESPACE> sh destroy.sh
```