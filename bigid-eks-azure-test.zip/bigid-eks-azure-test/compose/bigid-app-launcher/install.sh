#!/bin/bash
ls
NAMESPACE=$NAMESPACE
echo $NAMESPACE
#exit 1;

echo "______________________"
echo "Creating Roles"
echo "______________________"

kubectl create rolebinding argo-admin --clusterrole=cluster-admin --serviceaccount=$NAMESPACE:argo-server -n $NAMESPACE #to let web ui see api logs
kubectl create rolebinding argo-admin2 --clusterrole=cluster-admin --serviceaccount=$NAMESPACE:argo -n $NAMESPACE
echo "______________________"
echo "Creating Installation Files"
echo "______________________"

sed "s/\$NAMESPACE/$NAMESPACE/g" argo/manifests/install-template > argo/manifests/install.yaml
sed "s/\$NAMESPACE/$NAMESPACE/g" argo-events/manifests/install-template > argo-events/manifests/install.yaml
sed "s/\$NAMESPACE/$NAMESPACE/g" argo-trigger/webhook-gateway-template > argo-trigger/webhook-gateway.yaml
sed -e "s/\$NAMESPACE/$NAMESPACE/g" -e "s/\$SERVER/$SERVER/g" -e "s/\$CACERT/$CACERT/g" -e "s/\$TOKEN/$TOKEN/g" argo-trigger/webhook-sensor-template > argo-trigger/webhook-sensor.yaml



echo "______________________"
echo "Installing Argo Server"
echo "______________________"

kubectl apply -n $NAMESPACE -f argo/manifests/install.yaml
echo "______________________"
echo "Installing Argo Events"
echo "______________________"

kubectl apply -n $NAMESPACE -f argo-events/manifests/install.yaml

echo "______________________"
echo "Installing NATS"
echo "______________________"

kubectl apply -n $NAMESPACE -f argo-trigger/nats.yaml

echo "______________________"
echo "Installing Webhook Listener For Applauncher"
echo "______________________"

kubectl apply -n $NAMESPACE -f argo-trigger/webhook-eventsource.yaml
kubectl apply -n $NAMESPACE -f argo-trigger/webhook-gateway.yaml
kubectl apply -n $NAMESPACE -f argo-trigger/webhook-sensor.yaml

echo "______________________"
echo "Done" 