#!/bin/bash
ls
NAMESPACE=$NAMESPACE
echo $NAMESPACE
#exit 1;

echo "______________________"
echo "Uninstalling NATS and Webhook Listener For Applauncher"
echo "______________________"

kubectl delete -n $NAMESPACE -f argo-trigger/webhook-eventsource.yaml
kubectl delete -n $NAMESPACE -f argo-trigger/webhook-gateway.yaml
kubectl delete -n $NAMESPACE -f argo-trigger/webhook-sensor.yaml
kubectl delete -n $NAMESPACE -f argo-trigger/nats.yaml

echo "wait 5s"
sleep 5
echo "______________________"
echo "Uninstalling Argo Server"
echo "______________________"

kubectl delete -n $NAMESPACE -f argo/manifests/install.yaml
echo "______________________"
echo "Uninstalling Argo Events"
echo "______________________"

kubectl delete -n $NAMESPACE -f argo-events/manifests/install.yaml

echo "______________________"
echo "Deleting Roles"
echo "______________________"

kubectl delete rolebinding argo-admin -n $NAMESPACE
kubectl delete rolebinding argo-admin2 -n $NAMESPACE

echo "______________________"
echo "Done" 