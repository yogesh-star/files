# classification-sdk-demo-no-lib
An application that uses BigID's classification SDK, without the lib file.

This project uses a jar with all the related dependencies of BigID.

## Installation & Running
### install the jar
@todo, OREN - replace with an alternative command:

download lib from https://github.com/bigexchange/classifications-sdk-demo-lib/blob/master/classifications-0.0.1-SNAPSHOT-jar-with-dependencies.jar
Copy the file to lib/ dir.

For permissions - contact BigID community manager.

This is a maven project. You can install it with:
```
mvn clean
# make sure classifications-0.0.1-SNAPSHOT-jar-with-dependencies.jar is copied to  ~/.m2/repository/com/bigid/sdk/classifications
mvn install
```

## Usage

### A Complete Example
```java
import com.bigid.connectors.discovery.api.IdentityObject;
import com.bigid.sdk.classifications.*;
import com.bigid.sdk.classifications.dto.Findings;
//...
// It's recommended to initialize classificationSearcher and reuse the same object whenever needed
// initialize a discovery engine which detects only emails, with up to 100 occurrences for each text
ClassificationsSearcher classificationSearcher = new ClassificationsSearcherBuilder()
        .withDefaultClassifications(true)
        .withClassificationMatcherAmount(100)
        .build();

Set<String> actualResult = classificationSearcher.getEnabledClassifiers();
// use the above initialized objects
// search for emails in a text, and ignore the minimal and maximal length rules of BigID:
String Text = "the email@sample.com DE89 3704 0044 0532 0130 00 AccessToken=\"aaaaaaaaa\" 82-09-17-02-258 Alzheimer's Alzheimer\"s";
Findings findings = classificationSearcher.searchMatches(Text, false);
if (findings.isPiiFound()) {
    List<IdentityObject> classificationResults = findings.getIdentityObjects();
    for (IdentityObject identityObject : classificationResults) {
        System.out.println(identityObject.getWord() + ":" + Text.substring((int) identityObject.getPos() - 1, (int) identityObject.getEnd() - 1));
    }
}

```
### Parmeters explained
#### useAllClassifiers flag
By default some classifiers are turned off, either in BigID, or in the default classifications setup.
In order to use all classifiers, set this flag to true.

####  classificationMatcherAmount
In order to improve performance, it's better to limit the number of expected classifications in a text message.
By default, this value is 100.

#### withEnabledClassifiers
Use this method in order to choose a subset of the enabled classifiers.

### Available Modes
BigID classification SDK has 3 modes:
* default mode - use out of the box classifications.
* file mode - use a local file system to setup the default classifications.
* An online mode - use BigID as the source of classifications.

The manager of classifications mechanism is done with ClassificationsSearcher, which is initialized by ClassificationsSearcherBuilder.
* In order to initialize the default mode, use:
```java
 new ClassificationsSearcherBuilder()
        .withDefaultClassifications(useAllClassifiers)
```
* In order to initialize the file mode, use:
```java
 new ClassificationsSearcherBuilder()
        .withDefaultClassificationsFromLocalFile(useAllClassifiers, filePath)
```
* In order to initialize the online mode, use:
```java
 new ClassificationsSearcherBuilder()
        .withDefaultClassificationsFromLocalFile(useAllClassifiers, new BigIdConnection(bigIdBaseUrl,BigIdConnectionToken))
```

```java
//...
// It's recommended to initialize classificationsSearcher and reuse the same object whenever needed
// initialize a discovery engine which detects only emails, with up to 100 occurrences for each text
ClassificationsSearcher classificationsSearcher = new ClassificationsSearcherBuilder()
      .withDefaultClassifications(true)
      .withClassificationMatcherAmount(100)
      .withEnabledClassifiers(Set.of("Email"))
      .build();
```
