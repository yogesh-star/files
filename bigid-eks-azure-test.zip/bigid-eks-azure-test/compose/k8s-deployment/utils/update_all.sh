#!/bin/bash
TAG=${1:release}
NAMESPACE=${2:bigid}

kubectl --record deployment.apps/bigid-ui set image deployment.v1.apps/bigid-ui bigid-ui=$NAMESPACE/bigid-ui:$TAG
kubectl --record deployment.apps/bigid-web set image deployment.v1.apps/bigid-web bigid-web=$NAMESPACE/bigid-web:$TAG
kubectl --record deployment.apps/bigid-corr-new set image deployment.v1.apps/bigid-corr-new bigid-corr-new=$NAMESPACE/bigid-corr-new:$TAG
kubectl --record deployment.apps/bigid-orch set image deployment.v1.apps/bigid-orch bigid-orch=$NAMESPACE/bigid-orch:$TAG
kubectl --record deployment.apps/bigid-orch2 set image deployment.v1.apps/bigid-orch2 bigid-orch2=$NAMESPACE/bigid-orch:$TAG
kubectl --record deployment.apps/bigid-scanner set image deployment.v1.apps/bigid-scanner bigid-scanner=$NAMESPACE/bigid-scanner:$TAG
