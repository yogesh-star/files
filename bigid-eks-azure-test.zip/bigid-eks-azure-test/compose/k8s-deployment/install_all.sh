#!/usr/bin/env bash
source .setenv

kubectl create namespace ${INSTALL_NAMESPACE}

#Connect to MongoDB via SSL
#kubectl create secret generic bigid-mongo-secret --from-file certs/ca.cert -n  ${INSTALL_NAMESPACE}
#kubectl create secret generic bigid-mongo-client-cert --from-file certs/client.cert -n  ${INSTALL_NAMESPACE}
#kubectl create secret generic bigid-mongo-client-key --from-file certs/client.key -n  ${INSTALL_NAMESPACE}
#kubectl create secret generic bigid-java-trust-secret --from-file certs/truststore.jks -n ${INSTALL_NAMESPACE}
#kubectl create secret generic bigid-java-trust-client --from-file certs/client.jks -n ${INSTALL_NAMESPACE}

kubectl create secret tls tlssecret --key=${BIGID_CERTIFICATE_KEY} --cert=${BIGID_CERTIFICATE_FILE} -n ${INSTALL_NAMESPACE}

kubectl create configmap ui-nginx-config --from-file=../helm/files/nginx/nginx.conf -n ${INSTALL_NAMESPACE}

kubectl apply -f bigid-registry-pull-secret.yaml -n ${INSTALL_NAMESPACE}

for yaml in $(ls -d */*.yaml)
do
    envsubst < $yaml | kubectl apply -n ${INSTALL_NAMESPACE} -f -
done
