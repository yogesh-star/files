#!/usr/bin/env bash
./run-bigid-scanner.sh
