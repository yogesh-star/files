# Bigid Deployment Instructions on AKS

## Installation prerequisites

- az cli
- kubectl
- terraform
- helm

An Ubuntu VM to run deployment code from, or Azure Cloud Shell can be used.

Azure Container Registry with application images.

An ssh key-pair for the cluster nodes, or create one

      ssh-keygen -f ~/.ssh/clusterNodes -N ''

#### Note: Default location (~/.ssh/clusterNodes.pub) for cluster nodes' public key is defined in [terraform.tfvars](./terraform/infra/terraform.tfvars)

#

## Steps to deploy
<!---
1. Deploy Mongodb

   Create an virtual machine
   - Type: Standard_D4s_v3 
   - OS: Ubuntu 20.04

```
   az vm create \
      -g bigid-infra-rg \
      --image UbuntuLTS \
      -n bigid-mongodb \
      --vnet-name bigid-net \
      --subnet subnet-2 \
      --size Standard_B1MS \
      --nsg subnet-2-sg \
      --admin-username azureuser \
      --generate-ssh-keys \
      --public-ip-address ""
```

   ```
   # Install Docker and start a mongodb container :
   sudo apt update -y
   sudo apt install -y apt-transport-https ca-certificates curl software-properties-common
   curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo apt-key add -
   sudo add-apt-repository "deb [arch=amd64] https://download.docker.com/linux/ubuntu bionic stable"
   sudo apt update -y
   sudo apt install -y docker-ce
   sudo usermod -aG docker ${USER}
   sudo su - ${USER}
   sudo mkdir -p /var/lib/mongod/data
   docker run -d -p 27017:27017 \
      --restart=always \
      --name bigid-mongo \
      -e MONGO_INITDB_ROOT_USERNAME=bigid \
      -e MONGO_INITDB_ROOT_PASSWORD=password \
      -v /var/lib/mongod/data:/data/db mongo:3.6
   # Verify 
   docker exec -it bigid-mongo mongo -u bigid -p password
   ```
-->
1. Login to the VM and git clone this repository

         git clone https://github.com/squareops/bigid-eks
         cd bigid-eks


   Checkout the `azure` branch

         git checkout azure


2. Run [deps.sh](./deps.sh) to install all the required dependencies on the server

3. Login to az

         az login
         az account show

4. Create AKS Control Plane

   Prepare Azure storage account & container to store infrastructure state.

         cd terraform/backend
         terraform init
         terraform validate
         terraform plan -var-file=terraform.tfvars
         terraform apply -var-file=terraform.tfvars
         cd ../infra

   Setup parameters in [terraform.tfvars](./terraform/infra/terraform.tfvars)

         vim terraform.tfvars
         terraform init
         terraform validate
         terraform plan -var-file=terraform.tfvars
         terraform apply -var-file=terraform.tfvars

   This will create the AKS cluster with 2 node pools and set kubeconfig for administrator access to cluster resources. 

   For fine grained RBAC, Rancher's capabilities can be utillised, will be deployed in further steps.

   NOTE: This setup is tested on AKS version 1.20 . The version meta is also specified in [terraform.tfvars](./terraform/infra/terraform.tfvars)

   Nginx Ingress is also setup along with cluster. Nginx is deployed on `support` node group.

   Creates Azure Key Vault with necessary policies and configures cluster nodes and storage class to use custom disk encryption.

5. Get LoadBalancer IP/URL 

   ```
   kubectl get svc ingress-nginx-controller -n ingress-nginx | awk '{print $4}' | tail -1 
   ```

   The loadbalancer URL returned by above command will be used to point all subdomains (e.g. bigid-ui,rabbitmq and rancher as CNAME records )

6. Bootstrap the Cluster 

   This deployment supports only self managed SSL certificates and hence the certificates need to be manually imported in kubernetes

   ```
   kubectl create namespace cattle-system
   kubectl create secret tls tls-rancher-ingress --key /path/to/tls.key --cert /path/to/tls.crt -n cattle-system
   ```
   Make sure to point a dns name for rancher to loadbalancer's URL retrieved in above step and provide the same dns below in RANCHER_DNS env variable. 

   ```
   export RANCHER_DNS=rancher.bigid.squareops.xyz
   bash bootstrap.sh
   ```

7. Deploy bigid using Helm Chart and expose using ingress
      
   update values in below helm upgrade command as needed

   Change hostnames in bigid-eks/eks/manifests/ingress/bigid-ui-ingress.yaml and bigid-eks/eks/manifests/ingress/rabbitmq-ingress.yaml

   ```
   helm upgrade --install bigid-release compose/helm --set global.image.repository=507231466235.dkr.ecr.eu-central-1.amazonaws.com --set global.mongodb.externalIP=18.158.60.177 --set global.bigid.ner.create=true --set global.ingress.bigidHost=test.squareops.xyz --set global.ingress.rabbitmqHost=test1.squareops.xyz --set global.imageCredentials.username=anand91073 --set global.imageCredentials.password=Redhat#@1234 -f compose/helm/values.yaml
   ```
   NOTE: If rabbitmq takes time to spin up , correlators might fail. Need to find a way to define excution order or wait time

   Create Self-manage Certificate Secret for bigid-ui and bigid-rabbitmq and Replace these ssl certificate in eks/manifests/ssl/bigid-ui and eks/manifests/ssl/rabbitmq

   ```
   kubectl create secret tls bigid-ui-ssl-secret --key ./eks/manifests/ssl/bigid-ui/tls.key --cert ./eks/manifests/ssl/bigid-ui/tls.crt -n bigid
   
   kubectl create secret tls bigid-rabbitmq-ssl-secret --key ./eks/manifests/ssl/rabbitmq/tls.key --cert ./eks/manifests/ssl/rabbitmq/tls.crt -n bigid
  
   kubectl apply -f eks/manifests/ingress
   ```

8. Patch Bigid Deployment for customizations and scaling

   ```
   bash bigid-patch.sh
   ```

9. get service url
   ```
   kubectl get ingress --all-namespaces
   ```
