#### Create Bigid-standalone-depoyment ####
​
mkdir ./bigid-patch/bigid-standalone-deployment
​
kubectl get deploy bigid-scanner -n bigid -o yaml > ./bigid-patch/bigid-standalone-deployment/bigid-scanner-standalone.yaml -n bigid 2>/dev/null
​
sed -i 's|name: bigid-scanner|name: bigid-scanner-standalone|' ./bigid-patch/bigid-standalone-deployment/bigid-scanner-standalone.yaml
​
kubectl apply -f ./bigid-patch/bigid-standalone-deployment/bigid-scanner-standalone.yaml -n bigid
​
kubectl get deploy bigid-corr-new -n bigid -o yaml > ./bigid-patch/bigid-standalone-deployment/bigid-corr-new-standalone.yaml -n bigid 2>/dev/null
​
sed -i 's|name: bigid-corr-new|name: bigid-corr-new-standalone|' ./bigid-patch/bigid-standalone-deployment/bigid-corr-new-standalone.yaml
​
kubectl apply -f ./bigid-patch/bigid-standalone-deployment/bigid-corr-new-standalone.yaml -n bigid
​
###########################################
​
###### Patch Bigid Whole Deployment #######
​
kubectl patch deployment bigid-ui --patch "$(cat ./bigid-patch/affinity/bigid-ui-patch.yaml)" -n bigid
​
kubectl patch deployment bigid-web --patch "$(cat ./bigid-patch/affinity/bigid-web-patch.yaml)" -n bigid
​
kubectl patch deployment bigid-reports --patch "$(cat ./bigid-patch/affinity/bigid-reports-patch.yaml)" -n bigid
​
kubectl patch deployment bigid-orch --patch "$(cat ./bigid-patch/affinity/bigid-orch-patch.yaml)" -n bigid
​
kubectl patch deployment bigid-orch2 --patch "$(cat ./bigid-patch/affinity/bigid-orch2-patch.yaml)" -n bigid
​
kubectl patch deployment bigid-mq --patch "$(cat ./bigid-patch/affinity/bigid-mq-patch.yaml )" -n bigid
​
kubectl patch deployment bigid-ner --patch "$(cat ./bigid-patch/affinity/bigid-ner-patch.yaml )" -n bigid
​
kubectl patch deployment bigid-scanner --patch "$(cat ./bigid-patch/affinity/bigid-scanner-patch.yaml )" -n bigid
​
kubectl patch deployment bigid-corr-new --patch "$(cat ./bigid-patch/affinity/bigid-corr-new-patch.yaml )" -n bigid
​
kubectl patch deployment bigid-scanner-standalone --patch "$(cat ./bigid-patch/affinity/bigid-scanner-standalone-patch.yaml )" -n bigid
​
kubectl patch deployment bigid-scanner-standalone --patch "$(cat ./bigid-patch/affinity/bigid-corr-new-standalone.yaml )" -n bigid
​
################################################################################################################################
​
############### Deploy HPA #################
​
kubectl apply -f ./bigid-patch/hpa/
​
############################################
​
######### Clean-UP unused file #######################
​
rm -rf bigid-patch/bigid-standalone-deployment/
​
#######################################################
​
​
#### Configure HPA scale on Rabbit-Queue Depth ########
​
kubectl apply -f ./bigid-patch/rabbitmq-queue-depth/rabbitmq-exporter/rabbitmq-expoter.yaml
​
kubectl expose deploy mq-exporter --port=9419 -n bigid
​
helm repo add prometheus-community https://prometheus-community.github.io/helm-charts
​
helm repo add stable https://kubernetes-charts.storage.googleapis.com/
​
helm repo update
​
helm upgrade --install prometheus prometheus-community/prometheus \
    --namespace kube-system \
    --set alertmanager.persistentVolume.storageClass="default" \
    --set server.persistentVolume.storageClass="default" -f ./bigid-patch/rabbitmq-queue-depth/prometheus/values.yaml
​
helm upgrade --install --namespace kube-system prometheus-adapter prometheus-community/prometheus-adapter -f ./bigid-patch/rabbitmq-queue-depth/prometheus-adapter/config.yaml 
​
kubectl apply -f bigid-patch/rabbitmq-queue-depth/correlator-hpa/bigid-correlator-hpa.yaml
​
########################################################
​
